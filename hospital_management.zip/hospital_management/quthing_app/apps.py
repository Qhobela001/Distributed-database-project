from django.apps import AppConfig


class QuthingAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'quthing_app'
